title: python 实现斐波那契数列
date: '2020-06-10 22:37:21'
updated: '2020-06-10 22:37:21'
tags: [python]
permalink: /articles/2020/06/10/1591799841763.html
---
![](https://b3logfile.com/bing/20181101.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 第一种：递归

- 效率最低

```python
def Fibonaqi_recursion_tool(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return Fibonaqi_recursion_tool(n-1) + Fibonaqi_recursion_tool(n-2)


def Fibonaqi_recursion(n):
    result_list = []
    for i in range(0, n + 1):
        result_list.append(Fibonaqi_recursion_tool(i))
    return result_list


print(Fibonaqi_recursion(20))
```


### 第二种：循环

```python
def Fibonacci_loop(n):
    result_list = []
    a, b = 0, 1
    while n >= 0:
        result_list.append(a)
        a, b = b, a + b
        n -= 1
    return result_list


print(Fibonacci_loop(20))
```


### 第三种：yield关键字

```python
def Fibonacci_yield_tool(n):
    a, b = 0, 1
    while n >= 0:
        yield a
        a, b = b, a+b
        n -= 1


def Fibonacci_yield(n):
    return list(Fibonacci_yield_tool(n))


print(Fibonacci_yield(20))
```
