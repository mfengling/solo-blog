title: Python 技巧之推导式
date: '2020-06-17 17:59:36'
updated: '2020-06-17 17:59:36'
tags: [python]
permalink: /articles/2020/06/17/1592387976537.html
---
> 列表推导式(List Comprehensions)也是来自函数式编程语言，可以优雅的对一个序列进行数据筛选和处理得到一个结果列表。

比如，把一个列表中所有大于0的数平方后生产一个新的列表。

```
num = [-2, 3, 5, -4, 10, 7]
```

按常规做法，我们会

```
num = [-2, 3, 5, -4, 10, 7]
result = []
for x in num:
    if x > 0:
        result.append(x**2)
print result
```

然后，用列表推导式的话，只需要

```
print [x**2 for x in num if x > 0]
```

### 组成
把这个式子分成三个部分：输出处理、for循环、if判断。其中if判断部分是可选的。

if 判断部分是用来筛选。
输出处理部分比较灵活，随便自己想怎么处理。

比如有个列表A = [‘1’, ‘2’, ‘3’]，我们可以[int(x) for x in A]，把列表所有元素转换成int类型。

### 多个for循环

```
[(x, y) for x in range(3) for y in range(5)]
```

在这里，处理部分是(x, y)，其它按从左到右。等价于

```
for x in range(3):
    for y in range(5):
        #处理部分
```

### 嵌套列表推导式

```
[[0 for y in range(3)] for x in range(5)] 
```

在这里，处理部分是[0 for y in range(3)]，其它按从左到右。等价于

```
for x in range(5):
    #处理部分
```

### 多个if判断

```
[(x, y) for x in range(3) if x>1 for y in range(5) if y>2] 
```

在这里，处理部分是(x, y)，其它按从左到右。等价于

```
for x in range(3):
    if x>1:
        for y in range(5):
            if y>2:
                #处理部分
```

### 拓展

除了列表推导式。还有生成器推导式、集合推导式(python2.7及以上)、字典推导式(python2.7及以上)。

```
[x for x in range(3)] #-> 列表推导式
(x for x in range(3)) #-> 生成器推导式
{x for x in range(3)} #-> 集合推导式
{x:None for x in range(3)} #-> 字典推导式
```

比如

```
>>> d = {'a':1, 'b':2, 'c':3}
>>> d2 = {v:k for k,v in d.items()}#反向映射
>>> d2
{1: 'a', 2: 'b', 3: 'c'}
>>> d3 = {k:v.upper() for k,v in d2.items()}#把所有值都大写
>>> d3
{1: 'A', 2: 'B', 3: 'C'}
```
