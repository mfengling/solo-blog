title: Python3 base64编码与解码
date: '2020-06-17 09:41:34'
updated: '2020-06-17 10:00:19'
tags: [python, base64]
permalink: /articles/2020/06/17/1592358094419.html
---
### python的base64模块

Base64编码是从二进制到字符的过程，可用于在[HTTP](https://baike.baidu.com/item/HTTP)环境下传递较长的标识信息。采用Base64编码具有不可读性，需要解码后才能阅读。

```python3
import base64
  
# python3.x 中字符都为unicode编码，而b64encode函数的参数为byte类型，所以必须先转码。
# 想将字符串转编码成base64,要先将字符串转换成二进制数据，被编码的参数必须是二进制数据。

def safe_base64_code(s):
    if len(s) % 4 != 0:
        s = s + '=' * (4 - len(s) % 4)
    return s

s = input("输入要编码的字符串：")
encodebyte = base64.urlsafe_b64encode(s.encode('utf-8'))
print(f"{s} 编码（byte）：{encodebyte}")

encodestr = str(encodebyte, 'utf-8').strip('=+')
print(f"编码去除=号：{encodestr}")

decodebyte = safe_base64_code(encodestr)
print(f"编码增加=号后：{decodebyte}")

decodestr = base64.urlsafe_b64decode(decodebyte)
print(f'解码（byte）：{decodestr}')
print(f"解码（str）{str(decodestr,'utf-8')}")
```

- urlsafe_b64encode：此方法中用-代替了+，用_代替了/，这样可以保证编码后的字符串放在url里可以正常访问。

- 由于`=`字符也可能出现在Base64编码中，但`=`用在URL、Cookie里面会造成歧义。
