title: Weblogic安装与配置
date: '2020-06-14 22:14:16'
updated: '2020-06-14 22:14:16'
tags: [Weblogic]
permalink: /articles/2020/06/14/1592144056341.html
---
![](https://b3logfile.com/bing/20180518.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 配置jdk
```bash
tar -xf jdk-8u131-linux-x64.tar.gz
mv jdk1.8.0_131/ /usr/java
vim .bash_profile 
    # jdk环境变量set
    export JAVA_HOME=/usr/java
    export JRE_HOME=/usr/java/jre
    export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib
    PATH=$JAVA_HOME/bin:$PATH:$HOME/bin
    export PATH

source .bash_profile 
java -version
```

### 创建weblogic用户

```bash
useradd weblogic
mkdir /opt/weblogic
chown weblogic:weblogic /opt/weblogic/ -R
passwd weblogic
```

### 解压weblogic安装包

 使用weblogic用户，解压weblogic安装包

```bash
unzip fmw_12.2.1.3.0_wls_quick_Disk1_1of1.zip 
```
 
### Weblogic安装

安装目录

```bash
mkdir /opt/weblogic/oraInventory
mkdir /opt/weblogic/install
mkdir /opt/weblogic/weblogic12
```

```bash
# 产品清单目录；注意不能放在weblogic安装目录下,要保证安装目录为空
mv fmw_12.2.1.3.0_wls_quick.jar /opt/weblogic/install/
vim /opt/weblogic/install/oraInst.loc

    inventory_loc=/opt/weblogic/oraInventory
    inst_group=weblogic
```

创建响应文件（注意文件内容格式，都是顶格的）
```bash
vim /opt/weblogic/install/wls.rsp

[ENGINE]
#DO NOT CHANGE THIS
Response File Version=1.0.0.0.0
[GENERIC]
#weblogic的安装路径
ORACLE_HOME=/opt/weblogic/weblogic12
#Set this variable value to the Installation Type selected.e.g.     WebLogic Server, Coherence, Complete with Examples.
INSTALL_TYPE=WebLogic Server
DECLINE_SECURITY_UPDATES=true
SECURITY_UPDATES_VIA_MYORACLESUPPORT=false
```

静默安装，注意：初始化文件和响应文件一定要是全路径，（自定义的）。
```bash
java -jar fmw_12.2.1.3.0_wls_quick.jar -silent -responseFile /opt/weblogic/install/wls.rsp -invPtrLoc /opt/weblogic/install/oraInst.loc 
```

安装中耐心等待，出现Percent Complete : 100时安装完成。

安装完成信息
```
/opt/weblogic/install/oraInst.loc 
Launcher log file is /tmp/OraInstall2019-06-20_09-07-43AM/launcher2019-06-20_09-07-43AM.log.
Extracting the installer . . . . Done
......
Validations are enabled for this session.
Verifying data
Copying Files
Percent Complete : 10
......
Percent Complete : 100
The installation of Oracle Fusion Middleware 12c WebLogic and Coherence Developer 12.2.1.3.0 completed successfully.
Logs successfully copied to /opt/weblogic/install/wls12213/cfgtoollogs/oui.
```

### 创建domain

创建domain前在/opt/weblogic/install/wls12213/oracle_common/common/bin/config.sh 中添加随机数加快domin的创建。

```bash
cat /opt/weblogic/install/wls12213/oracle_common/common/bin/config.sh 

    #!/bin/sh
    SCRIPTNAME=$0
    SCRIPTPATH=`dirname "${SCRIPTNAME}"`
    # Delegate to the common delegation script ...
    "${SCRIPTPATH}/fmwconfig_common.sh" config_internal.sh "$@"
    JVM_ARGS="-Djava.security.egd=file:///dev/urandom-Dpython.cachedir=/tmp/cachedir ${JVM_D64} ${UTILS_MEM_ARGS}${SECURITY_JVM_ARGS} ${CONFIG_JVM_ARGS}"
```

采用wlst脚本来建立domain
```bash
cat /opt/weblogic/install/create_domain.py

readTemplate('/opt/weblogic/install/wls12213/wlserver/common/templates/wls/wls.jar')
cd('Servers/AdminServer')
set('ListenPort',7001)
cd('/')
cd('Security/base_domain/User/weblogic')
#如果需要修改管理员用户名为weblogic，则需要cmo.setName('weblogic')
cmo.setName('weblogic')
#用户名
cmo.setPassword('weblogic123')
#密码
setOption('ServerStartMode','prod')
setOption('OverwriteDomain','true')
writeDomain('/opt/weblogic/weblogic12/user_projects/proddomain')
#自定义的domin路径
closeTemplate()
exit()
```

开始创建domain

```bash
sh /opt/weblogic/install/wls12213/oracle_common/common/bin/wlst.sh  /opt/weblogic/install/create_domain.py 

Initializing WebLogic Scripting Tool (WLST) ...
Welcome to WebLogic Server Administration Scripting Shell
Type help() for help on available commands
Exiting WebLogic Scripting Tool.
```

### 查询新补丁

查询当前是否有补丁

`sh /opt/weblogic/install/wls12213/OPatch/opatch lsinventory`

### 优化

修改句柄数(root用户)

```bash
vim /etc/security/limits.conf

wlsoper  hard          nofile  10240
wlsoper   soft          nofile  10240
```

### domain相关配置

添加domain随机数，指定编码方式

```bash
vim /opt/weblogic/weblogic12/user_projects/proddomain/bin/setDomainEnv.sh
JAVA_OPTIONS="${JAVA_OPTIONS} -Dfile.encoding=utf-8 -Djava.security.egd=file:///dev/urandom"
export JAVA_OPTIONS
```

修改权限，修改umask 027为umask 002

`vim /opt/weblogic/weblogic12/user_projects/proddomain/bin/startWebLogic.sh `

加入部分参数，加速 Admin Server 停止

```bash
SH> vim /opt/weblogic/weblogic12/user_projects/proddomain/bin/stopWebLogic.sh 

echo "shutdown('${SERVER_NAME}','Server', ignoreSessions='true',timeOut=0,force='true')" >>"shutdown-${SERVER_NAME}.py"
```

### 启动weblogic
#### 测试启动

需要输入用户名和密码，出现 RUNNING启动成功，可以去网页的控制台http://ip:7001/console

`sh /opt/weblogic/weblogic12/user_projects/proddomain/bin/startWebLogic.sh`

    
#### 在控制台添加server
http://10.10.10.210:7001/console

环境—->服务器—>点击锁定并编辑—>点击新建

* 服务器名：appserver1（自定义）
* 服务器监听地址：10.10.10.210 （这是adminserver的地址，如果server放在别的服务器上就填那台服务器的ip地址）
* 服务器监听端口： 8001

点击完成，再点激活更改，不点的话配置信息就不能写到config.xml里，要不启动server时会报错


#### 自启动脚本

> 脚本可放到其他目录

设置Adminserver启动时就不需要输入密码

```bash
mkdir /opt/weblogic/weblogic12/user_projects/proddomain/servers/AdminServer/security
vim /opt/weblogic/weblogic12/user_projects/proddomain/servers/AdminServer/security/boot.properties
username=********
password=********
mkdir /opt/weblogic/weblogic12/user_projects/proddomain/servers/appserver1/security
vim /opt/weblogic/weblogic12/user_projects/proddomain/servers/appserver1/security/boot.properties
username=********
password=********
```

Adminserver启动脚本

```bash
mkdir /opt/weblogic/weblogic12/user_projects/proddomain/logs
cat /opt/weblogic/weblogic12/user_projects/proddomain/strAdminServer.sh
#!/bin/bash
base_dir="/opt/weblogic/weblogic12/user_projects/proddomain/"
scripts_dir="/opt/weblogic/weblogic12/user_projects/proddomain/bin"
out_log="/opt/weblogic/weblogic12/user_projects/proddomain/logs/AdminServer.out"
err_log="/opt/weblogic/weblogic12/user_projects/proddomain/logs/AdminServer.err"
gc_log="/opt/weblogic/weblogic12/user_projects/proddomain/logs/AdminServer_gc.out"
if [ -f $out_log ];then
mv $out_log $base_dir/logs/AdminServer`date +%Y-%m-%d-%H:%M:%S`.out
fi
if [ -f $err_log ];then
mv $err_log $base_dir/logs/AdminServer`date +%Y-%m-%d-%H:%M:%S`.err
fi
if [ -f $gc_log ];then
mv $gc_log $base_dir/logs/AdminServer_gc`date +%Y-%m-%d-%H:%M:%S`.out
fi
nohup sh $scripts_dir/startWebLogic.sh 1> $out_log 2> $err_log &
sleep 5
tail -100f $out_log
```

Adminserver停止脚本

```bash
cat /opt/weblogic/weblogic12/user_projects/proddomain/stpAdminServer.sh
#!/bin/bash
scripts_dir="/opt/weblogic/weblogic12/user_projects/proddomain/bin"
sh $scripts_dir/stopWebLogic.sh
```

server 启动脚本

```bash
cat /opt/weblogic/weblogic12/user_projects/proddomain/startappserver1.sh
#!/bin/bash
base_dir="/opt/weblogic/weblogic12/user_projects/proddomain/"
scripts_dir="/opt/weblogic/weblogic12/user_projects/proddomain/bin"
out_log="/opt/weblogic/weblogic12/user_projects/proddomain/logs/appserver1.out"
err_log="/opt/weblogic/weblogic12/user_projects/proddomain/logs/appserver1.err"
gc_log="/opt/weblogic/weblogic12/user_projects/proddomain/logs/appserver1_gc.out"
if [ -f $out_log ];then
mv $out_log $base_dir/logs/appserver1`date +%Y-%m-%d-%H:%M:%S`.out
fi
if [ -f $err_log ];then
mv $err_log $base_dir/logs/appserver1`date +%Y-%m-%d-%H:%M:%S`.err
fi
if [ -f $gc_log ];then
mv $gc_log $base_dir/logs/appserver1_gc`date +%Y-%m-%d-%H:%M:%S`.out
fi
nohup sh $scripts_dir/startManagedWebLogic.sh appserver1 http://10.10.10.210:7001 1> $base_dir/logs/appserver1.out 2> $base_dir/logs/appserver1.err &
sleep 5
tail -100f $out_log
```

serverde 停止脚本

```bash
cat /opt/weblogic/weblogic12/user_projects/proddomain/stopappserver1.sh
#!/bin/bash
scripts_dir="/opt/weblogic/weblogic12/user_projects/proddomain/bin"
sh $scripts_dir/stopManagedWebLogic.sh appserver1 http://10.10.10.210:7001
```

#### 测试脚本

启动adminserver

`sh strAdminServer.sh `

启动appserver1

`SH> sh startappserver1.sh `


