title: Mysql5.7 二进制安装
date: '2020-06-28 12:20:20'
updated: '2020-06-28 12:20:20'
tags: [mysql]
permalink: /articles/2020/06/28/1593318020743.html
---
### 1. 解压mysql包
指定应用安装目录：/app

```
mkdir /app && cd /app
tar xf mysql-5.7.29-linux-glibc2.12-x86_64
mv mysql-5.7.29-linux-glibc2.12-x86_64/ mysql/
```


### 2. 环境配置
- 配置env，方便执行命令
- 建立mysql用户和组
- 指定data目录和赋予权限
- 卸载mariadb-libs包

```
rpm -e mariadb-libs-5.5.65-1.el7.x86_64 --nodeps
export PATH=/app/mysql/bin:$PATH
source /etc/profile
useradd -s /usr/sbin/nologin  mysql
mkdir /data/mysql
chown -R mysql:mysql /app/mysql/*
chown -R mysql:mysql /data/mysql/
```


### 3. 初始化数据
> **5.7开始,MySQL加入了全新的 密码的安全机制:**
**1.初始化完成后,会生成临时密码(显示到屏幕上,并且会往日志中记一份)**
**2.密码复杂度:长度:超过12位? 复杂度:字符混乱组合**
**3.密码过期时间180天**

- 方法一：生成mysql的root用户的临时密码。

```
mysqld --initialize --user=mysql --basedir=/app/mysql/ --datadir=/data/mysql/
```

- 方法二：mysql的root用户的密码为empty。

```
mysqld --initialize-insecure --user=mysql --basedir=/app/mysql/ --datadir=/data/mysql/
```

>  **5.6初始化数据使用的命令：/mysql/scripts/mysql_install_db，参数一致。** 



### 4. 默认配置文件

```
[mysqld]
user=mysql
basedir=/app/mysql
datadir=/data/mysql
server_id=6
port=3306
socket=/tmp/mysql.sock
[mysql]
socket=/tmp/mysql.sock
prompt=3306 [\\d]>
```


### 5. 启动服务配置

- Sys v 管理

```
cp /app/mysql/support-files/mysql.server /etc/init.d/mysqld
/etc/init.d/mysqld start
```

- systemd管理

```
vim /etc/systemd/system/mysqld.service
	[Unit]
	Description=MySQL Server
	Documentation=man:mysqld(8)
	Documentation=http://dev.mysql.com/doc/refman/en/using-systemd.html
	After=network.target
	After=syslog.target
	[Install]
	WantedBy=multi-user.target
	[Service]
	User=mysql
	Group=mysql
	ExecStart=/app/mysql/bin/mysqld --defaults-file=/etc/my.cnf
	LimitNOFILE = 5000

systemctl start mysqld
```


> 5.6 中用户基本信息:
select user,password,host from mysql.user;
5.7 中用户基本信息:
select user,authentication_string,host from mysql.user;
desc  mysql.user;


### 6. 修改root用户密码

```
mysqladmin -uroot -p password xx
```
