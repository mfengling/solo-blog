title: Python 列表与字典互转
date: '2020-06-17 17:36:05'
updated: '2020-06-17 17:36:05'
tags: [python]
permalink: /articles/2020/06/17/1592386565698.html
---
### 嵌套列表转字典
```python
list1 = [['id', '1'], ['name', 'admin'], ['ip', '10.10.10.10']]
dict1 = dict(list1)
print(dict1)


dict2 = {}
for i in list1:
    dict2[i[0]] = i[1]

print(dict2)
```


### 两个列表转一个字典
```python
keys = ['id', 'name', 'ip']
values = ['1', 'admin', '10.10.10.10']
dict3 = dict(zip(keys, values))
print(dict3)
```


### 特殊列表转字典
```python
keyses = ['id', 'name', 'ip']
valueses = [['1', 'admin', '10.10.10.10'], ['2', 'prt', '192.168.122.128']]
# keyses = []
# valueses = []
dict4 = [dict(zip(keyses, row)) for row in valueses] if valueses else None
print(dict4)
```


### 字典转列表
```python
dict5 = {
        'name':'zsd',
        'age':'16',
        'gender':'male',
        'addr':'sh'
        }
list1 = list(dict5.keys())
print(list1)
list2 = list(dict5.values())
print(list2)


list3, list4 = [], []
for k, v in dict5.items():
    list3.append(k)
    list4.append(v)

print(list3, list4)
```
