title: 认识html
date: '2020-06-15 22:49:41'
updated: '2020-06-15 22:49:41'
tags: [html]
permalink: /articles/2020/06/15/1592232581161.html
---
![](https://b3logfile.com/bing/20180613.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### html结构标准

后缀名不能决定文件格式，只能决定打开文件打开的方式。

```html
< ! doctype html>    声明文档类型

<html>              根标签

<head>             头标签

<title></title>       标题标签

</head>

<body>             主体标签

</body>

</html>
```

### html标签分类

单标签    `<! Doctype html>`

双标签    `<html></html>   <head></head>   <title></title>`



### html标签关系分类

包含（嵌套）    `<head><title></title></head>`

并列关系    `<head></head><body></body>`


### 标签

#### 单标签

* 注释标签    `ctrl + /`
* 换行标签    `<br>`
* 水平线标签    `<hr>`

#### 双标签

* 段落标签    `<p>文本内容</p>`
	* 特点：上下自动生成空白行。<br>换行不会生成空白行。
* 标题标签，共6级    `<h1></h1>;......;<h6></h6>`
	* h1在一个页面只能出现一次
* 文本标签     `<font>文本内容</font>`
* 文本加粗标签    `<strong></strong>`    `<b></b>`，尽量使用strong
* 文本倾斜标签    `<em><em>`    `<i></i>`，尽量使用em
* 删除线标签    `<del></del>`    `<s></s>`，尽量使用del
* 下划线标签    `<ins><ins>`    `<u><u>`，尽量使用ins

#### 图片标签

`<img src="" alt="" title="" width="" height="">`

* src：图片来源，必填
* alt：替换文本，图片不显示时，文字会显示
* title：提示文本，鼠标放到图片上显示的文字
* width：图片宽度
* height：图片高度

> 图片没有定义宽高时，图片按百分百比例显示，如果只改变宽度或高度，图片等比例缩放显示。


### 超链接

`<a href="" title="" target="">超链接</a>`

* href：跳转的页面，必填属性
* title：提示文本，鼠标放在链接上显示的文字
* target：默认值为`_self`，关闭自身页面，打开链接页面；`_blank` 打开新页面


### 锚链接

1. 先定义一个锚点，`<p id="top"></p>`
2. 超链接到锚点，`<a href="#top">回到顶部</a>`


### 空链
不知道链接到哪个页面时，使用空链。
`<a href="#">空链</a>`


### 超链接优化写法
让所有的超链接在新页面打开
`<base target="_blank">`


### 特殊字符

特殊字符 | 描述 | 字符的代码
--- | --- | ---
` ` | 空格符 | `&nbsp;`
`<` | 小于号 | `&lt;`
`>` | 大于号 | `&gt;`
`&` | 和号 | `&amp;`
`￥` | 人民币 | `&yen;`
`©` | 版权 | `&copy;`
`®` | 注册商标 | `&reg;`
`℃` | 摄氏度 | `&deg;`
`±` | 正负号| `&plusmn;`
`×` | 乘号 | `&times;`
`÷` | 除号 | `divide;`
`²` | 平方 | `&sup2;`
`³` | 立方 | `&sup3`


### 列表

#### 无序列表

* type：`square` 小方块； `disc` 实心小圆圈； `circle` 空心小圆圈；
* li：列表项

```html
<ul type="" >
	<li></li>
	<li></li>
	<li></li>
</ul>
```

#### 有序列表
* type：`1`； `a`； `A`； `i`； `I`；
* start：决定了开始的位置

```html
<ol type="" start="">
	<li></li>
	<li></li>
	<li></li>
</ol>
```

#### 自定义列表

* dt：小标题
* dd：解释标题

```html
<dl>
	<dt>帮助中心</dt>
	<dd>购物指南</dd>
	<dd>订单操作</dd>
	<dd>账号管理</dd>
</dl>
```


### 音乐标签

* hidden：隐藏播放按钮，true隐藏，false显示

`<embed src="活着.mp3" hidden="true">`


### 滚动标签

页面自动滚动效果，中间的内容可以是文字或图片。

`<marquee>...</marquee>`

* height：高度
* width：高度
* bgcolor：背景颜色
* behavior：滚动的方式
	* alternate：在两端之间来回滚动。
	* scroll：由一端滚动到另一端，会重复。
	* slide：由一端滚动到另一端，不会重复。
* direction：滚动的方向
	* down：向下滚动
	* left：向左滚动
	* right：向右滚动
	* up：向上滚动
* loop：滚动的次数，-1一直滚下去。

