title: Python 对日期时间数据的处理
date: '2020-06-18 09:40:13'
updated: '2020-06-18 09:40:27'
tags: [python]
permalink: /articles/2020/06/18/1592444412942.html
---
> 后端接受到前端的时间数据，是字符串str，若需要用时间数据做查询，需要的格式是datetime.datetime。

### 字符串转时间

- datetime.strptime(字符串,时间格式)

例子:

- 函数 datetime.datetime.strptime()
- datetime.strptime(str,'%Y-%m-%d')

```python
from datetime import datetime


time = "2020/03/07 - 2020/03/31"
starttime, endtime = time.split('-')
start_time = starttime.strip().replace('/', '-') + ' 00:00:00'
starttimes = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')

print(start_time)
print(starttimes)
print(type(start_time))
print(type(starttimes))

```


### 时间转字符串

- 时间.strftime(时间格式)
- 函数 strftime()
- datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

```python
from datetime import datetime


strf = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

print(strf)
print(type(strf))
```

### 常用时间格式

格式符 | 中文说明 | 英文说明
--- | --- | --- 
%a  | 星期几的简写  | Weekday name, abbr.
%A  | 星期几的全称  | Weekday name, full
%b  | 月分的简写 |  Month name, abbr.
%B  | 月份的全称 |  Month name, full
%c  | 标准的日期的时间串 |  Complete date and time representation
%d  | 十进制表示的每月的第几天 |  Day of the month
%H  | 24小时制的小时  | Hour (24-hour clock)
%I  | 12小时制的小时  | Hour (12-hour clock)
%j  | 十进制表示的每年的第几天 |  Day of the year
%m  | 十进制表示的月份 |  Month number
%M  | 十时制表示的分钟数 |  Minute number
%S  | 十进制的秒数 |  Second number
%U  | 第年的第几周，把星期日做为第一天（值从0到53） | Week number (Sunday first weekday)
%w  | 十进制表示的星期几（值从0到6，星期天为0） | weekday number
%W  | 每年的第几周，把星期一做为第一天（值从0到53）  | Week number (Monday first weekday)
%x  | 标准的日期串 |  Complete date representation (e.g. 13/01/08)
%X  | 标准的时间串  | Complete time representation (e.g. 17:02:10)
%y  | 不带世纪的十进制年份 | （值从0到99）Year number within century
%Y  | 带世纪部分的十制年份  | Year number
%z，%Z  | 时区名称，如果不能得到时区名称则返回空字符。 | Name of time zone
%%  | 百分号  |  -
