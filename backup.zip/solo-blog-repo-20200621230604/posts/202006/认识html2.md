title: 认识html（2）
date: '2020-06-16 23:15:49'
updated: '2020-06-16 23:16:27'
tags: [html]
permalink: /articles/2020/06/16/1592320549307.html
---
### 关键字

`<meta name="keywords" content="java, python, c++">`

### 网页描述

`<meta name="description" content="人生苦短，我用python。">`

### 网页重定向

`<meta http-equiv="refresh" content="5; http://baidu.com">`

* 5：5秒后跳转


### 链接外部样式表

`<link rel="stylesheet" href="1.css">`


### 设置icon图标

`<link rel="icon" href="favicon.ico">`


### 表格

```html
<table border="1" width="500" height="300" cellspacing="0" cellpadding="10" align="center" bgcolor="yellow">
        <tr align="center">
            <td>111111</td>
            <td>222222</td>
            <td>333333</td>
        </tr>
        <tr>
            <td>4444444</td>
            <td>555</td>
            <td>666666666</td>
        </tr>
    </table>
```
* table：表
* tr：行
* td：列
* border：边框
* width：宽度
* height：高度
* cellspacing：单元格与单元格的距离
* cellpadding：内容距边框的距离
* align：
	* left：靠左
	* right：靠右
	* center：居中
* bgcolor：背景颜色


