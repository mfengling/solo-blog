title: Oracle server端字符集修改
date: '2020-06-14 22:17:22'
updated: '2020-06-14 22:17:22'
tags: [Oracle]
permalink: /articles/2020/06/14/1592144242183.html
---
### oracle server 端 字符集查询

`select userenv(‘language’) from dual;`

### 查询oracle client端的字符集
`$echo $NLS_LANG`

如果发现你select 出来的数据是乱码，请把client端的字符集配置成与linux操作系统相同的字符集。

### server端字符集修改

```bash
sqlplus / as sysdba

shutdown immediate

startup mount

alter system enable restricted session;

alter system set job_queue_processes=0;

alter system set aq_tm_processes=0;

alter database open;

alter database character set internal_use ZHS16GBK;
```
